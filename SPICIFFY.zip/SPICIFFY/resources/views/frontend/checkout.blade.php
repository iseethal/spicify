@include('frontend.templates.header')
@include('frontend.templates.toastr-notifications')


<style>
    .tp-checkout-btn {
        background-color: #006677;
    }
</style>

<main>

    <!-- breadcrumb area start -->
    <section class="breadcrumb__area include-bg pt-95 pb-50" data-bg-color="#EFF1F5">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12">
                    <div class="breadcrumb__content p-relative z-index-1">
                        <h3 class="breadcrumb__title">Checkout</h3>
                        <div class="breadcrumb__list">
                            <span><a href="{{ route('frontend.home') }}">Home</a></span>
                            <span>Checkout</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb area end -->


    <section class="tp-checkout-area" data-bg-color="#EFF1F5">
        <div class="container">
           <div class="row">
              <div class="col-xl-7 col-lg-7">
                 <div class="tp-checkout-verify">

                    <div class="tp-checkout-verify-item">
                       <p class="tp-checkout-verify-reveal">Have a coupon? <button type="button" class="tp-checkout-coupon-form-reveal-btn">Click here to enter your code</button></p>

                       <div id="tpCheckoutCouponForm" class="tp-return-customer">

                         <form action="{{ route('coupon.apply') }}"  method="POST" >
                             @csrf
                             <div class="tp-return-customer-input">
                                <label>Coupon Code :</label>
                                <input type="text" name="coupon_code" id="coupon_code" placeholder="Coupon">
                             </div>
                             <button type="submit" class="tp-return-customer-btn tp-checkout-btn">Apply</button>
                          </form>
                       </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </section>
    <!-- checkout area start -->

    <form action="{{ route('checkout.store') }}" method="POST">
        @csrf
    <section class="tp-checkout-area pb-120" data-bg-color="#EFF1F5">
       <div class="container">
          <div class="row">
             <div class="col-lg-7">
                <div class="tp-checkout-bill-area">
                    <h3 class="tp-checkout-bill-title">Billing Details</h3>

                    <div class="tp-checkout-bill-form">
                            <div class="tp-checkout-bill-inner">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="tp-checkout-input">
                                            <label>First Name <span>*</span></label>

                                            <input type="text" name="billing_firstname" id="billing_firstname"
                                                 placeholder="First Name" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="tp-checkout-input">
                                            <label>Last Name <span>*</span></label>
                                            <input type="text" name="billing_lastname" id="billing_lastname"
                                                placeholder="Last Name" required>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="tp-checkout-input">
                                            <label>Country / Region </label>
                                            <input type="text" name="country" id="country"
                                                placeholder="country" required>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="tp-checkout-input">
                                            <label>Street address</label>
                                            <input type="text" name="billing_address1" id="billing_address1"
                                                placeholder="House number and street name" required>
                                        </div>

                                        <div class="tp-checkout-input">
                                            <input type="text" name="billing_address2" id="billing_address2"
                                                placeholder="Apartment, suite, unit, etc. (optional)" required>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="tp-checkout-input">
                                            <label>State</label>
                                            <input type="text" name="billing_state" id="billing_state"
                                                placeholder="state" required>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="tp-checkout-input">
                                            <label>Town / City</label>
                                            <input type="text" name="billing_city" id="billing_city"
                                                placeholder="city" required>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="tp-checkout-input">
                                            <label>Postcode ZIP</label>
                                            <input type="text" id="billing_zip_code" type="text"
                                                name="billing_zip_code" placeholder="pin code" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="tp-checkout-input">
                                            <label>Phone <span>*</span></label>
                                            <input type="number" name="billing_phone" id="billing_phone"
                                                placeholder="phone" required>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="tp-checkout-input">
                                            <label>Email address <span>*</span></label>
                                            <input type="email" name="billing_email" id="billing_email"
                                                type="email" placeholder="email" required>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="tp-checkout-input">
                                            <label>Order notes (optional)</label>
                                            <textarea id="order_notes" type="text" name="order_notes"
                                                placeholder="Notes about your order, e.g. special notes for delivery."></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>

                    </div>
                </div>
            </div>


            <div class="col-lg-5">
                <!-- checkout place order -->
                <div class="tp-checkout-place white-bg">
                    <h3 class="tp-checkout-place-title">Your Order</h3>

                    <div class="tp-order-info-list">
                        <ul>

                            <!-- header -->
                            <li class="tp-order-info-list-header">
                                <h4>Product</h4>
                                <h4>Total</h4>
                            </li>

                            <!-- item list -->
                            @php $grandtotal = 0; @endphp
                            @foreach ($cart as $item)
                                <li class="tp-order-info-list-desc">
                                    <p>{{ $item->product_name }}. <span> x {{ $item->quantity }}</span></p>
                                    <span>₹{{ $item->amount }}</span>
                                </li>

                                @php
                                    $grandtotal += $item->total_amount;
                                @endphp
                            @endforeach


                            <!-- subtotal -->
                            <li class="tp-order-info-list-subtotal">
                                <span>Subtotal</span>
                                <span>₹{{ $grandtotal }} </span>
                            </li>

                            <li class="tp-order-info-list-total">
                                <span>Total</span>
                                <span>₹{{ $grandtotal }}</span>
                            </li>
                        </ul>
                    </div>
                    <div class="tp-checkout-payment">

                        <div class="tp-checkout-payment-item">
                            <input type="radio" id="cod" name="payment_type" value="cash_on_delivery">
                            <label for="cod">Cash on Delivery</label>

                        </div>
                        <div class="tp-checkout-payment-item paypal-payment">
                            <input type="radio" id="paypal" name="payment_type" value="pay_now">
                            <label for="paypal">Pay Now <img src="assets/img/icon/payment-option.png"
                                    alt=""> <a href="#">What is PayPal?</a></label>
                        </div>
                    </div>

                    <div class="tp-checkout-btn-wrapper">
                        <button type="submit" class="tp-checkout-btn w-100">Place Order</button>
                    </div>
                </div>
            </div>

          </div>
       </div>
    </section>

</form>

    <!-- checkout area end -->


 </main>
      <script src="assets/js/bootstrap-bundle.js"></script>
      <script src="assets/js/meanmenu.js"></script>
      <script src="assets/js/slick.js"></script>
      <script src="assets/js/range-slider.js"></script>
      <script src="assets/js/magnific-popup.js"></script>
      <script src="assets/js/nice-select.js"></script>
      <script src="assets/js/purecounter.js"></script>
      <script src="assets/js/countdown.js"></script>
      <script src="assets/js/wow.js"></script>
      <script src="assets/js/isotope-pkgd.js"></script>
      <script src="assets/js/imagesloaded-pkgd.js"></script>
      <script src="assets/js/ajax-form.js"></script>
      <script src="assets/js/main.js"></script>

@include('frontend.templates.footer')
