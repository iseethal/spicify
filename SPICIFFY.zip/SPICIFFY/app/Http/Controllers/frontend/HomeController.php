<?php

namespace App\Http\Controllers\frontend;

use App\Models\Cart;
use App\Models\Slider;
use App\Models\Category;
use App\Models\WishList;
use Illuminate\Http\Request;
use App\Models\CompareProduct;
use App\Models\VariantOptions;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class HomeController extends Controller
{
    //

    public function Home()
    {
        $categories        = Category::where('is_active','=',1)->where('is_deleted','<>',1)->get();
        $variant_options   = VariantOptions::where('is_active','=',1)->where('is_deleted','<>',1)->get();
        $featured_products = VariantOptions::where('is_active','=',1)->where('is_deleted','<>',1)->where('is_featured','=',1)->get();
        $sliders           = Slider::where('is_active','=',1)->get();
        $wishlist = session()->get('wishlist', []);


        if(Auth::id()){

            if(Session::has('cart')){

                $cart = session()->get('cart', []);
                foreach (session('cart') as $id =>  $cart_items ){

                    $variant_option_id = $cart_items['id'];
                    $product_name      = $cart_items['product_name'];
                    $image             = $cart_items['image'];
                    $quantity          = $cart_items['quantity'];
                    $amount            = $cart_items['amount'];
                    $total_amount      = $amount * $quantity;

                    $cart                    = new Cart;
                    $cart->user_id           = Auth::id();
                    $cart->variant_option_id = $variant_option_id;
                    $cart->product_name      = $product_name;
                    $cart->image             = $image;
                    $cart->quantity          = $quantity;
                    $cart->amount            = $amount;
                    $cart->total_amount      = $total_amount;
                    $cart->save();

                }

                $cart = session()->forget('cart');

             }

             if(Session::has('wishlist')){

                $wishlist = session()->get('wishlist', []);
                foreach (session('wishlist') as $id =>  $wishlist_items ){

                    $variant_option_id = $wishlist_items['id'];
                    $product_name      = $wishlist_items['product_name'];
                    $image             = $wishlist_items['image'];
                    $quantity          = $wishlist_items['quantity'];
                    $amount            = $wishlist_items['amount'];

                    $wishlist                    = new WishList;
                    $wishlist->user_id           = Auth::id();
                    $wishlist->variant_option_id = $variant_option_id;
                    $wishlist->product_name      = $product_name;
                    $wishlist->image             = $image;
                    $wishlist->quantity          = $quantity;
                    $wishlist->amount            = $amount;
                    $wishlist->save();

                }

                $wishlist = session()->forget('wishlist');
             }

             if(Session::has('compare')){

                $compare = session()->get('compare', []);
                foreach (session('compare') as $id =>  $compare_items ){

                    $variant_option_id = $compare_items['id'];
                    $product_name      = $compare_items['product_name'];
                    $image             = $compare_items['image'];
                    $quantity          = $compare_items['quantity'];
                    $amount            = $compare_items['amount'];

                    $compare                    = new CompareProduct;
                    $compare->user_id           = Auth::id();
                    $compare->variant_option_id = $variant_option_id;
                    $compare->product_name      = $product_name;
                    $compare->image             = $image;
                    $compare->quantity          = $quantity;
                    $compare->amount            = $amount;
                    $compare->save();

                }

                $compare = session()->forget('compare');
             }


        }

        return view('frontend.home',compact('categories','variant_options','featured_products','sliders'));
    }
}
