<?php echo $__env->make('frontend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.templates.toastr-notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php
use App\Models\CompareProduct;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
$product_count = CompareProduct::where('user_id', Auth::id())->count();

?>

<style>
    .tp-compare-add-to-cart .tp-btn:hover {
        background-color: #006677;
        border-color: #006677;
        color: var(--tp-common-white);
    }

    .tp-compare-product-title a:hover {
        color: #006677;
    }
</style>

<main>

    <!-- breadcrumb area start -->
    <section class="breadcrumb__area include-bg pt-95 pb-50">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12">
                    <div class="breadcrumb__content p-relative z-index-1">
                        <h3 class="breadcrumb__title">Compare</h3>
                        <div class="breadcrumb__list">
                            <span><a href="<?php echo e(route('frontend.home')); ?>">Home</a></span>
                            <span>Compare</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb area end -->

    <?php if(session('compare')): ?>

        <section class="tp-compare-area pb-120">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="tp-compare-table table-responsive text-center">
                            <table class="table">
                                <tbody>

                                    <tr>
                                        <th>Product</th>
                                        <?php $__currentLoopData = session('compare'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $compare_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td data-id="<?php echo e($id); ?>">
                                                <div class="tp-compare-desc">
                                                    <img src="<?php echo e(url('backend/images/product_images/' . $compare_items['image'])); ?>"
                                                        width="205px" height="176px" alt="">
                                                    <h4 class="tp-compare-product-title">
                                                        <a
                                                            href="<?php echo e(route('frontend.single_product', ['id' => $compare_items['id']])); ?>"><?php echo e(Str::limit($compare_items['product_name'], 20)); ?></a>
                                                    </h4>
                                                </div>
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tr>
                                    <tr>
                                        <th>Description</th>

                                        <?php $__currentLoopData = session('compare'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $compare_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td data-id="<?php echo e($id); ?>">
                                                <div class="tp-compare-desc">
                                                    <p style="white-space: pre-line"><?php echo e($compare_items['features']); ?>

                                                    </p>
                                                </div>
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tr>
                                    <tr>
                                        <th>Price</th>

                                        <?php $__currentLoopData = session('compare'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $compare_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td data-id="<?php echo e($id); ?>">
                                                <div class="tp-compare-price">
                                                    <span>₹<?php echo e($compare_items['amount']); ?></span>
                                                    
                                                </div>
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tr>

                                    <tr>
                                        <th>Add to cart</th>
                                        <?php $__currentLoopData = session('compare'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $compare_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $enquiry = App\Models\VariantOptions::where('id', $id)
                                                    ->pluck('enquiry')
                                                    ->first();
                                            ?>

                                            <?php if($enquiry == 0): ?>
                                                <form action="<?php echo e(route('cart.store', ['id' => $id])); ?>" method="post">
                                                    <?php echo csrf_field(); ?>

                                                    <input type="hidden" name="product_id" id="product_id"
                                                        value="<?php echo e($id); ?>">
                                                    <input type="hidden" name="product_qty" id="product_qty"
                                                        value="1">
                                                    <input type="hidden" name="compare_id" id="compare_id"
                                                        value="<?php echo e($id); ?>">


                                                    <td data-id="<?php echo e($id); ?>">
                                                        <div class="tp-compare-add-to-cart">
                                                            <button type="submit" class="tp-btn">Add to Cart</button>
                                                        </div>
                                                    </td>
                                                </form>
                                            <?php else: ?>
                                                <td>
                                                    <div class="tp-compare-add-to-cart">
                                                        <a
                                                            href="<?php echo e(route('frontend.single_product', ['id' => $id])); ?>">
                                                            <button type="submit" class="tp-btn">Enquire Now</button>
                                                        </a>
                                                    </div>
                                                </td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tr>

                                    <tr>
                                        <th>Remove</th>

                                        <?php $__currentLoopData = session('compare'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $compare_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td>
                                                <form action="<?php echo e(route('remove.from.compare')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>

                                                    <input type="hidden" name="compare_id" id="compare_id"
                                                        value="<?php echo e($id); ?>">

                                                    <button type="submit" class="tp-cart-action-btn">
                                                        <svg width="10" height="10" viewBox="0 0 10 10"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M9.53033 1.53033C9.82322 1.23744 9.82322 0.762563 9.53033 0.46967C9.23744 0.176777 8.76256 0.176777 8.46967 0.46967L5 3.93934L1.53033 0.46967C1.23744 0.176777 0.762563 0.176777 0.46967 0.46967C0.176777 0.762563 0.176777 1.23744 0.46967 1.53033L3.93934 5L0.46967 8.46967C0.176777 8.76256 0.176777 9.23744 0.46967 9.53033C0.762563 9.82322 1.23744 9.82322 1.53033 9.53033L5 6.06066L8.46967 9.53033C8.76256 9.82322 9.23744 9.82322 9.53033 9.53033C9.82322 9.23744 9.82322 8.76256 9.53033 8.46967L6.06066 5L9.53033 1.53033Z"
                                                                fill="currentColor" />
                                                        </svg>
                                                        <span>Remove</span>
                                                    </button>
                                                </form>
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php elseif($product_count != 0): ?>
        <?php if(auth()->guard()->check()): ?>
            <section class="tp-compare-area pb-120">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="tp-compare-table table-responsive text-center">
                                <table class="table">
                                    <tbody>

                                        <tr>
                                            <th>Product</th>
                                            <?php $__currentLoopData = $compare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compare_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <div class="tp-compare-desc">
                                                        <img src="<?php echo e(url('backend/images/product_images/' . $compare_items['image'])); ?>"
                                                            width="205px" height="176px" alt="">
                                                        <h4 class="tp-compare-product-title">
                                                            <a
                                                                href="<?php echo e(route('frontend.single_product', ['id' => $compare_items['variant_option_id']])); ?>"><?php echo e(Str::limit($compare_items->product_name, 20)); ?></a>
                                                        </h4>
                                                    </div>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tr>
                                        <tr>
                                            <th>Description</th>

                                            <?php $__currentLoopData = $compare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compare_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <div class="tp-compare-desc">
                                                        <p style="white-space: pre-line"><?php echo e($compare_items['features']); ?>

                                                        </p>
                                                    </div>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tr>
                                        <tr>
                                            <th>Price</th>

                                            <?php $__currentLoopData = $compare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compare_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <div class="tp-compare-price">
                                                        <span>₹<?php echo e($compare_items['amount']); ?></span>
                                                        
                                                    </div>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tr>


                                        <tr>
                                            <th>Add to cart</th>
                                            <?php $__currentLoopData = $compare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compare_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $id = $compare_items->variant_option_id;
                                                    $enquiry = App\Models\VariantOptions::where('id', $id)
                                                        ->pluck('enquiry')
                                                        ->first();
                                                ?>

                                                <?php if($enquiry == 0): ?>
                                                    <form
                                                        action="<?php echo e(route('compare.to.cart', ['id' => $compare_items->variant_option_id])); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>

                                                        <input type="hidden" name="id" id="id"
                                                            value="<?php echo e($compare_items->id); ?>">

                                                        <input type="hidden" name="product_id" id="product_id"
                                                            value="<?php echo e($compare_items->variant_option_id); ?>">
                                                        <input type="hidden" name="product_qty" id="product_qty"
                                                            value="1">
                                                        <input type="hidden" name="compare_id" id="compare_id"
                                                            value="<?php echo e($compare_items->id); ?>">

                                                        <td>
                                                            <div class="tp-compare-add-to-cart">
                                                                <button type="submit" class="tp-btn">Add to Cart</button>
                                                            </div>
                                                        </td>
                                                    </form>
                                                <?php else: ?>
                                                    <td>
                                                        <div class="tp-compare-add-to-cart">
                                                            <a
                                                                href="<?php echo e(route('frontend.single_product', ['id' => $compare_items['variant_option_id']])); ?>">
                                                                <button type="submit" class="tp-btn">Enquire Now</button>
                                                            </a>
                                                        </div>
                                                    </td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tr>



                                        <tr>
                                            <th>Remove</th>

                                            <?php $__currentLoopData = $compare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compare_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <form action="<?php echo e(route('remove.from.compare')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>

                                                        <input type="hidden" name="id" id="id"
                                                            value="<?php echo e($compare_items->id); ?>">
                                                        <input type="hidden" name="product_id" id="product_id"
                                                            value="<?php echo e($compare_items->id); ?>">
                                                        <input type="hidden" name="product_qty" id="product_qty"
                                                            value="1">


                                                        <button type="submit" class="tp-cart-action-btn">
                                                            <svg width="10" height="10" viewBox="0 0 10 10"
                                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M9.53033 1.53033C9.82322 1.23744 9.82322 0.762563 9.53033 0.46967C9.23744 0.176777 8.76256 0.176777 8.46967 0.46967L5 3.93934L1.53033 0.46967C1.23744 0.176777 0.762563 0.176777 0.46967 0.46967C0.176777 0.762563 0.176777 1.23744 0.46967 1.53033L3.93934 5L0.46967 8.46967C0.176777 8.76256 0.176777 9.23744 0.46967 9.53033C0.762563 9.82322 1.23744 9.82322 1.53033 9.53033L5 6.06066L8.46967 9.53033C8.76256 9.82322 9.23744 9.82322 9.53033 9.53033C9.82322 9.23744 9.82322 8.76256 9.53033 8.46967L6.06066 5L9.53033 1.53033Z"
                                                                    fill="currentColor" />
                                                            </svg>
                                                            <span>Remove</span>
                                                        </button>
                                                    </form>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tr>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    <?php else: ?>
        <div class="container" style="margin-top: 25px;width: 40%;">
            <div class="container-fluid">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <center>
                            <h4>Your compare products is empty </h4>
                            <a href="<?php echo e(route('frontend.shop')); ?>">back to the shop page</a>
                        </center>
                    </div>
                </div>
            </div>
        </div>



    <?php endif; ?>



</main>


<?php echo $__env->make('frontend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\shiya\LARAVEL\SPICIFFY\resources\views/frontend/compare_products.blade.php ENDPATH**/ ?>