<?php echo $__env->make('backend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- InternalFileupload css-->
<link href="<?php echo e(asset('backend/assets/plugins/fileuploads/css/fileupload.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('backend/assets/plugins/fancyuploder/fancy_fileupload.css')); ?>" rel="stylesheet" />


<!-- Main Content-->
<div class="main-content side-content pt-0">
    <div class="container-fluid">
        <div class="inner-body">

            <!-- Page Header -->
            <div class="page-header">
                <div>
                    <h2 class="main-content-title tx-24 mg-b-5">Enquiry Edit</h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('enquiry.all')); ?>">Enquiry</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Edit</li>
                    </ol>
                </div>

            </div>
            <!-- End Page Header -->
            <?php if(Session::has('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong> <?php echo e(session::get('error')); ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <!-- Row -->
            <div class="row row-sm">

                <div class="col-lg-12 col-md-12">
                    <div class="card custom-card">
                        <div class="card-body">

                            <form action="<?php echo e(route('enquiry.update', ['id' => $enquiry->id])); ?>" method="POST"
                                enctype="multipart/form-data">

                                <?php echo csrf_field(); ?>

                                <p style="font-size: 16px"> <b>Edit Customer Details</b></p>
                                <div class="">

                                    <div class="row row-xs align-items-center mg-b-20">
                                        <div class="col-md-4">
                                            <label class="mg-b-0"> Customer Name</label>
                                        </div>
                                        <div class="col-md-8 mg-t-5 mg-md-t-0">
                                            <input class="form-control" name="name" id="name"
                                                value="<?php echo e($enquiry->name); ?>" placeholder="Enter name"
                                                type="text" required>
                                        </div>
                                    </div>

                                    <div class="row row-xs align-items-center mg-b-20">
                                        <div class="col-md-4">
                                            <label class="mg-b-0"> Mobile</label>
                                        </div>
                                        <div class="col-md-8 mg-t-5 mg-md-t-0">
                                            <input class="form-control" name="mobile"
                                                value="<?php echo e($enquiry->phone); ?>" id="mobile"
                                                placeholder="Enter mobile" type="number" >
                                        </div>
                                    </div>

                                    <div class="row row-xs align-items-center mg-b-20">
                                        <div class="col-md-4">
                                            <label class="mg-b-0"> Email</label>
                                        </div>
                                        <div class="col-md-8 mg-t-5 mg-md-t-0">
                                            <input class="form-control" name="email" id="email"
                                                value="<?php echo e($enquiry->email); ?>" placeholder="Enter email"
                                                type="text">
                                        </div>
                                    </div>

                                    <div class="row row-xs align-items-center mg-b-20">
                                        <div class="col-md-4">
                                            <label class="mg-b-0">Address</label>
                                        </div>
                                        <div class="col-md-8 mg-t-5 mg-md-t-0">
                                            <input class="form-control" name="address" id="address"
                                                placeholder="Enter address" type="text"
                                                value="<?php echo e($enquiry->address); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group row justify-content-end mb-0">
                                        <div class="col-md-8 pl-md-2">
                                            <button type="submit" class="btn ripple btn-primary pd-x-30 mg-r-5"
                                                style="background-color: #006677;">Update</button>
                                            <!-- <button class="btn ripple btn-secondary pd-x-30">Cancel</button> -->
                                        </div>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Row -->

        </div>
    </div>
</div>
<!-- End Main Content-->

<?php echo $__env->make('backend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\GisAxiom\KRISTLE\kriztle_project\resources\views/backend/enquiry/edit_enquiry.blade.php ENDPATH**/ ?>