<?php

namespace App\Http\Controllers\backend;

use App\Models\VariantOptions;
use App\Models\Variants;
use App\Models\Category;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class VariantOptionsController extends Controller
{
    public function AllVariantOptions()
    {
        $variant_options = VariantOptions::where('is_deleted','<>', 1)->get();
        return view('backend.variant_options.all_variant_options', compact('variant_options'));
    }

    public function AddVariantOption()
    {
        $variants   = Variants::where('is_deleted','<>', 1)->get();
        $categories = Category::where('is_deleted','<>', 1)->where('is_active','=', 1)->get();
        return view('backend.variant_options.add_variant_option', compact('variants', 'categories'));
    }

    public function StoreVariantOption(Request $request)
    {

        if($request->file('image')!= null){
            $file       = $request->file('image');
            $filename   = $file->getClientOriginalName();
            $request->image->move(public_path('backend/images/product_images'),$filename);
            $path       = "public/backend/images/product_images/$filename";
        }
        else{
            $filename = "";
        }

        // support_image1
        if($request->file('support_image1')!= null){
            $file             = $request->file('support_image1');
            $support_image1   = $file->getClientOriginalName();
            $request->support_image1->move(public_path('backend/images/product_images'),$support_image1);
            $path             = "public/backend/images/product_images/$support_image1";
        }
        else{
            $support_image1 = "";
        }

        // support_image2
        if($request->file('support_image2')!= null){
            $file             = $request->file('support_image2');
            $support_image2   = $file->getClientOriginalName();
            $request->support_image2->move(public_path('backend/images/product_images'),$support_image2);
            $path             = "public/backend/images/product_images/$support_image2";
        }
        else{
            $support_image2 = "";
        }

        // support_image3
        if($request->file('support_image3')!= null){
            $file             = $request->file('support_image3');
            $support_image3   = $file->getClientOriginalName();
            $request->support_image3->move(public_path('backend/images/product_images'),$support_image3);
            $path             = "public/backend/images/product_images/$support_image3";
        }
        else{
            $support_image3 = "";
        }

        // support_image4
        if($request->file('support_image4')!= null){
            $file             = $request->file('support_image4');
            $support_image4   = $file->getClientOriginalName();
            $request->support_image4->move(public_path('backend/images/product_images'),$support_image4);
            $path             = "public/backend/images/product_images/$support_image4";
        }
        else{
            $support_image4 = "";
        }

        $variant_id  = 0;
        // $category_id = Variants::where('id',$variant_id)->pluck('category_id')->first();

        VariantOptions::insert([

            'category_id'     => $request->category_id,
            // 'variant_id'      => $variant_id,
            'name'            => $request->name,
            'amount'          => $request->amount?? 0,
            'image'           => $filename?? "",
            'support_image1'  => $support_image1?? "",
            'support_image2'  => $support_image2?? "",
            'support_image3'  => $support_image3?? "",
            'support_image4'  => $support_image4?? "",
            'features'        => $request->features?? "",
            // 'specifications'  => $request->specifications?? "",
            'is_featured'     => $request->is_featured?? 0,
            // 'clearance_sale'  => $request->clearance_sale?? 0,
            'enquiry'         => $request->enquiry??1,
            'is_active'       => $request->is_active,
        ]);

        return redirect()->route('variant_options.all')->with('success', 'Variant Option Added' );
    }

    public function EditVariantOption(Request $request)
    {
        $id        		  = $request->id;
        $variant_options  = VariantOptions::findOrFail($id);
        $variants         = Variants::where('is_deleted','<>', 1)->get();
        $categories       = Category::where('is_deleted','<>', 1)->where('is_active','=', 1)->get();

        return view('backend.variant_options.edit_variant_option', compact('variant_options', 'variants', 'categories'));
    }

    public function UpdateVariantOption(Request $request, $id)
    {

        $id        		  = $request->id;
        $variant_options  = VariantOptions::findOrFail($id);

        if(request()->hasFile('image') && request('image') != ''){

            // $imagePath = public_path('backend/images/product_images/'.$variant_options->image);
            // if($variant_options->image != null ){
            //     unlink($imagePath);
            // }

            $file       = $request->file('image');
            $filename   = $file->getClientOriginalName();
            $request->image->move(public_path('backend/images/product_images'),$filename);
            $path       = "public/backend/image/product_images/$filename";
        }

        // support_image1
        if(request()->hasFile('support_image1') && request('support_image1') != ''){

            $imagePath1 = public_path('backend/images/product_images/'.$variant_options->support_image1);

            if($variant_options->support_image1 != null){
                unlink($imagePath1);
            }

            $file             = $request->file('support_image1');
            $support_image1   = $file->getClientOriginalName();
            $request->support_image1->move(public_path('backend/images/product_images'),$support_image1);
            $path             = "public/backend/image/product_images/$support_image1";
        }

        // support_image2
        if(request()->hasFile('support_image2') && request('support_image2') != ''){

            $imagePath2 = public_path('backend/images/product_images/'.$variant_options->support_image2);

            if($variant_options->support_image2 != null){
                unlink($imagePath2);
            }

            $file             = $request->file('support_image2');
            $support_image2   = $file->getClientOriginalName();
            $request->support_image2->move(public_path('backend/images/product_images'),$support_image2);
            $path             = "public/backend/image/product_images/$support_image2";
        }

          // support_image3
          if(request()->hasFile('support_image3') && request('support_image3') != ''){

            $imagePath3 = public_path('backend/images/product_images/'.$variant_options->support_image3);

            if($variant_options->support_image3 != null){
                unlink($imagePath3);
            }

            $file             = $request->file('support_image3');
            $support_image3   = $file->getClientOriginalName();
            $request->support_image3->move(public_path('backend/images/product_images'),$support_image3);
            $path             = "public/backend/image/product_images/$support_image3";
        }

        // support_image4
        if(request()->hasFile('support_image4') && request('support_image4') != ''){

            $imagePath4 = public_path('backend/images/product_images/'.$variant_options->support_image4);
            // if($variant_options->support_image4 != null ){
            //     unlink($imagePath4);
            // }

            $file             = $request->file('support_image4');
            $support_image4   = $file->getClientOriginalName();
            $request->support_image4->move(public_path('backend/images/product_images'),$support_image4);
            $path             = "public/backend/image/product_images/$support_image4";
        }


        $image   = VariantOptions::where('id',$id)->pluck('image')->first();
        $image1  = VariantOptions::where('id',$id)->pluck('support_image1')->first();
        $image2  = VariantOptions::where('id',$id)->pluck('support_image2')->first();
        $image3  = VariantOptions::where('id',$id)->pluck('support_image3')->first();
        $image4  = VariantOptions::where('id',$id)->pluck('support_image4')->first();

        $variant_id  = 0;
        // $category_id = Variants::where('id',$variant_id)->pluck('category_id')->first();

        VariantOptions::findOrFail($id)->update([

            'category_id'    => $request->category_id,
            // 'variant_id'     => $request->variant_id,
            'name'           => $request->name,
            'amount'         => $request->amount,
            'image'          => $filename?? $image,
            'support_image1' => $support_image1??$image1,
            'support_image2' => $support_image2??$image2,
            'support_image3' => $support_image3??$image3,
            'support_image4' => $support_image4??$image4,
            'features'       => $request->features?? "",
            'enquiry'        => $request->enquiry,
            // 'specifications' => $request->specifications?? "",
            'is_featured'    => $request->is_featured ?? 0,
            // 'clearance_sale'  => $request->clearance_sale?? 0,
            'is_active'      => $request->is_active,
        ]);

        return redirect()->back();
        // return redirect()->route('variant_options.all')->with('success', 'Variant Option Updated' );
    }

    public function DeleteVariantOption($id)
    {
        VariantOptions::findOrFail($id)->update([

            'is_deleted'     => 1,
        ]);
        return redirect()->back()->with('error', 'Variant Option Removed' );
    }
}
