<?php echo $__env->make('backend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- Main Content-->
<div class="main-content side-content pt-0">
<div class="container-fluid">
<div class="inner-body">


    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h2 class="main-content-title tx-24 mg-b-5"> Products</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"> All Products</li>
            </ol>
        </div>

        <a href="<?php echo e(route('products.add')); ?>">
                <button class="btn ripple btn-main-primary"><i class="fe fe-plus mr-2"></i>Add New</button>
            </a>
    </div>
    <!-- End Page Header -->
    
    <!-- Row -->
    <div class="row row-sm">
        <div class="col-lg-12">
            <div class="card custom-card overflow-hidden">
                <div class="card-body">

                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>  <?php echo e(session::get('success')); ?></strong> 
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <div>
                        <!-- <h6 class="main-content-label mb-1">Products</h6> -->
                        <!-- <p class="text-muted card-sub-title">Exporting data from a table can often be a key part of a complex application. The Buttons extension for DataTables provides three plug-ins that provide overlapping functionality for data export:</p> -->
                        
                    </div>
                    <div class="table-responsive">
                        <table id="exportexample" class="table table-bordered border-t0 key-buttons text-nowrap w-100" >
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>name </th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    
                                   
                                    <?php

                                    $status_is = $style = "";
                                    if ($item->is_active == 1) 
                                    {
                                        $status_is    = "Active";
                                        $style 		  = "style=color:green;";
                                    }
                                    else
                                    {
                                        $status_is    = "InActive";
                                        $style 		  = "style=color:red;";
                                    }
                                    
                                    ?>

                                    <td <?php echo e($style); ?>><?php echo e($status_is); ?></td>
                                    
                                    <td>
                                        <a href="<?php echo e(route('products.edit',['id'=>$item['id']])); ?>"><i class="fa fa-edit"></i></a> &nbsp;&nbsp;&nbsp;&nbsp; 
                                        <a href="<?php echo e(route('products.delete',$item->id)); ?>"> <i class="fa fa-remove"></i></a>   
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Row -->


</div>
</div>
</div>
<!-- End Main Content-->



<?php echo $__env->make('backend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\shiya\LARAVEL\KRIZTLE\kriztle_project\resources\views/backend/products/all_products.blade.php ENDPATH**/ ?>