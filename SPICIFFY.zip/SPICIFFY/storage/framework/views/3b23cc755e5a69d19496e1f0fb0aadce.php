<?php echo $__env->make('frontend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<style>
    .tp-checkout-btn {
        background-color: #006677;
    }
</style>

<main>

    <!-- breadcrumb area start -->
    <section class="breadcrumb__area include-bg text-center pt-95 pb-50">
        <div class="container">
           <div class="row">
              <div class="col-xxl-12">
                 <div class="breadcrumb__content p-relative z-index-1">
                    <h3 class="breadcrumb__title">MY ACCOUNT</h3>
                    <div class="breadcrumb__list">
                       <span><a href="<?php echo e(route('frontend.home')); ?>">Home</a></span>
                       <span>My Account</span>
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </section>
    <!-- breadcrumb area end -->



    <!-- checkout area start -->
    <section class="tp-contact-area pb-100">
        <div class="container">
           <div class="tp-contact-inner">

            <div class="myaccount-content">
                <br><br>
                <h6>YOUR ORDERS</h6><br>

                <div class="myaccount-table table-responsive text-center">
                  <table class="table table-bordered">
                    <thead class="thead-light">
                      <tr>
                       <tr>
                       <th>No</th>
                          <th>Order Id</th>
                          <th>Date</th>
                          <th>Item</th>
                          <th>Total</th>
                          <th>Status</th>
                      </tr>
                    </thead>

                    <?php ($i = 1)   ?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                        $order_id    = $item->id;
                        $order_items = App\Models\OrderItem::where('order_id', $order_id)->get();

                        $status_is = $style = "";

                        if ( $item->order_status == 0)
                        {
                            $status_is    = "Order Placed";
                            $style        = "style=color:red;";

                        }
                        elseif( $item->order_status == 1)
                        {
                            $status_is    = "In Progress";
                            $style        = "style=color:green;";

                        }
                        else{

                            $status_is    = "Delivered";
                            $style        = "style=color:green;";
                        }

                        $order_date = $item->order_date;
                        ?>

                    <tbody>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($order_date); ?></td>

                            <td>
                                <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($item1->product_name ."  ×  ". $item1->quantity ."  - ".$item1->amount); ?> <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>

                            <td><?php echo e($item->total); ?></td>
                            <td <?php echo e($style); ?>><?php echo e($status_is); ?></td>
                        </tr>




                     </tbody>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </table>
                </div>
              </div>

           </div>
        </div>
     </section>
    <!-- checkout area end -->


</main>



<?php echo $__env->make('frontend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\GisAxiom\KRISTLE\kriztle_project\resources\views/frontend/myaccount.blade.php ENDPATH**/ ?>