<?php

namespace App\Http\Controllers\frontend;

use App\Models\Enquiry;
use App\Models\Category;
use App\Models\Variants;
use Illuminate\Http\Request;
use App\Models\VariantOptions;
use Illuminate\Support\Carbon;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;

class ShopController extends Controller
{

    public function Shop(Request $request)
    {

        $id                = $request->get('id');
        $categories        = Category::where('is_deleted', '<>', 1)->where('is_active', '=', 1)->get();
        $variant_id        = $request->variant_id;
        $category_id       = Variants::where('id', $variant_id)->pluck('category_id')->first();
        $featured_products = VariantOptions::where('is_active', '=', 1)->where('is_deleted', '<>', 1)->where('is_featured', '=', 1)->get();


        if (!empty($request->get('id'))) {

            $variant_options = VariantOptions::where('category_id', $id)->where('is_deleted', '<>', '1')->where('is_active', '=', '1')->orderBy('id', 'desc')->paginate(9)->withQueryString();
        } else if ($variant_id != null) {

            $variant_options = VariantOptions::where('category_id', $category_id)->where('variant_id', $variant_id)->where('is_deleted', '<>', '1')->where('is_active', '=', '1')->orderBy('id', 'desc')->paginate(9)->withQueryString();
        } else if ($request->input('query') != null) {

            $variant_options = VariantOptions::where('name', 'like', '%' . $request->input('query') . '%')
                ->paginate(15)->withQueryString();
        } else {

            $variant_options = VariantOptions::orderBy('id', 'desc')->where('is_deleted', '<>', '1')->where('is_active', '=', '1')->paginate(9)->withQueryString();
        }


        return view('frontend.shop', compact('categories', 'variant_options', 'featured_products'));
    }

    public function ProductDetails(Request $request)
    {

        $id              = $request->id;
        $variant_options = VariantOptions::findOrFail($id);
        $category_id     = $variant_options->category_id;

        $relatedProduct  = VariantOptions::where('category_id', '=', $category_id)
            ->where('is_deleted', '<>', '1')
            ->where('is_active', '=', '1')
            ->where('id', '!=', $id)
            ->get();


        return view('frontend.single_product', compact('variant_options', 'relatedProduct'));
    }



    public function ClearanceSale(Request $request)
    {
        $id                = $request->get('id');
        $categories        = VariantOptions::where('is_active', '=', 1)->where('is_deleted', '<>', 1)->where('clearance_sale', '=', 1)->select('category_id')->get()->unique('category_id');
        $variant_id        = $request->variant_id;
        $category_id       = Variants::where('id', $variant_id)->pluck('category_id')->first();
        $featured_products = VariantOptions::where('is_active', '=', 1)->where('is_deleted', '<>', 1)->where('is_featured', '=', 1)->get();

        if (!empty($request->get('id'))) {

            $variant_options = VariantOptions::where('category_id', $id)->where('is_deleted', '<>', '1')->where('clearance_sale', '=', 1)->where('is_active', '=', '1')->orderBy('id', 'desc')->paginate(9)->withQueryString();
        } else if ($variant_id != null) {

            $variant_options = VariantOptions::where('category_id', $category_id)->where('variant_id', $variant_id)->where('is_deleted', '<>', '1')->where('is_active', '=', '1')->where('clearance_sale', '=', 1)->orderBy('id', 'desc')->paginate(9)->withQueryString();
        } else if ($request->input('query') != null) {

            $variant_options = VariantOptions::where('name', 'like', '%' . $request->input('query') . '%')->where('clearance_sale', '=', 1)->paginate(15)->withQueryString();
        } else {

            $variant_options = VariantOptions::orderBy('id', 'desc')->where('is_deleted', '<>', '1')->where('is_active', '=', '1')->where('clearance_sale', '=', 1)->paginate(9)->withQueryString();
        }

        return view('frontend.clearance_sale', compact('categories', 'variant_options', 'featured_products'));
    }

    public function index()
    {
    	return view('frontend.search');
    }
    public function selectSearch(Request $request)
    {
    	$movies = [];
        if($request->has('q')){
            $search = $request->q;
            $movies =VariantOptions::select("id", "name")
            		->where('name', 'LIKE', "%$search%")
            		->get();
        }
        return response()->json($movies);
    }

}
