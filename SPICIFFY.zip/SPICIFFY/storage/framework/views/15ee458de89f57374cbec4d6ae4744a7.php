<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<style>
    table,
    td,
    th {
        border: 1px solid black;
        border-collapse: collapse;
    }

    table {
        width: 700px;
        margin-left: auto;
        margin-right: auto;
    }

    td,
    caption {
        padding: 16px;
    }

    th {
        padding: 16px;
        background-color: lightblue;
        text-align: left;
    }
</style>

<body>
    <?php
        $id = $order->id;
    ?>

    <table>
        <caption><b> Invoice </b></caption>
        <tr>
            <th colspan="3">Invoice #<?php echo e($id); ?></th>
            <th><?php echo e(\Carbon\Carbon::parse(now())->format('d M Y')); ?></th>
        </tr>
        <tr>
            <td colspan="2">
                <strong>Invoice Form:</strong> <br>
                Kriztle Gallery, P.T Usha Road <br>
                Cochin - 682 011 <br>
                Thrippunithura<br>
                Kerala State, India<br>
                +9947053222, 9961492022
            </td>
            <td colspan="2">
                <strong>Invoice To:</strong> <br>
                <?php echo e($order->billing_firstname); ?> <?php echo e($order->billing_lastname); ?><br>
                <?php echo e($order->billing_phone); ?> <br>
                <?php if( $order->billing_address1 != null): ?>
                <?php echo e($order->billing_address1); ?><br>
                <?php endif; ?>
                <?php if( $order->billing_address2 != null): ?>
                <?php echo e($order->billing_address2); ?><br>
                <?php endif; ?>
                <?php if( $order->country != null): ?>
                <?php echo e($order->country); ?>,
                <?php endif; ?>
                <?php if( $order->billing_state != null): ?>
                <?php echo e($order->billing_state); ?>,
                <?php endif; ?>
                <?php if( $order->billing_city != null): ?>
                <?php echo e($order->billing_city); ?><br>
                <?php endif; ?>
                <?php if( $order->billing_zip_code != null): ?>
                <?php echo e($order->billing_zip_code); ?><br>
                <?php endif; ?>
            </td>
        </tr>


         <?php $i=1; ?>

        <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <?php echo e($i++); ?> </td>
                <td> <?php echo e($items->product_name); ?> </td>
                <td> <?php echo e($items->quantity); ?> </td>
                <td> <?php echo e($items->amount); ?> </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <th colspan="3">Subtotal:</th>
            <td><?php echo e($order->total); ?></td>
        </tr>
        
        <tr>
            <th colspan="3">Grand Total:</th>
            <td><?php echo e($order->total); ?></td>

        </tr>
    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\shiya\LARAVEL\eCommerce\resources\views/backend/invoice/invoice_view.blade.php ENDPATH**/ ?>