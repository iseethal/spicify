<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VariantOptions extends Model
{
    use HasFactory;

    protected $table = 'variant_options';

    protected $fillable = [

        'category_id',
        'variant_id',
        'name',
        'amount',
        'image',
        'support_image1',
        'support_image2',
        'support_image3',
        'support_image4',
        'features',
        'specifications',
        'is_featured',
        'clearance_sale',
        'enquiry',
        'is_active',
        'is_deleted',
    ];

    public $timestamps = false;

}
