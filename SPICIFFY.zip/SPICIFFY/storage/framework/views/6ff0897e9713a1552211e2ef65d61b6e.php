<?php echo $__env->make('backend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- Main Content-->
<div class="main-content side-content pt-0">
<div class="container-fluid">
<div class="inner-body">


	<!-- Page Header -->
	<div class="page-header">
		<div>
			<h2 class="main-content-title tx-24 mg-b-5">Profile</h2>
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
				<li class="breadcrumb-item active" aria-current="page">Profile</li>
			</ol>
		</div>


	</div>
	<!-- End Page Header -->

	<!-- Row -->
	<div class="row row-sm">
		<div class="col-lg-12">
			<div class="card custom-card overflow-hidden">
				<div class="card-body">

				<?php if(Session::has('success')): ?>
				<div class="alert alert-success alert-dismissible fade show" role="alert">
				<strong>  <?php echo e(session::get('success')); ?></strong>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>
				<?php endif; ?>

					<div class="table-responsive">
						<table id="exportexample" class="table table-bordered border-t0 key-buttons text-nowrap w-100" >
							<thead>
								<tr>
									<th>Id</th>
									<th>Name</th>
									<th>Role</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>

							<?php $i=1 ?>

							<?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php
                                        $role = $item->role;
                                        if($role == 1)
                                        {
                                            $role_is = "Admin";
                                        }
                                    ?>

								<tr>
									<td><?php echo e($i++); ?></td>
									<td><?php echo e($item->name); ?></td>
									<td><?php echo e($role_is); ?></td>
									<td>
										<a href="<?php echo e(route('password.change',['id'=>$item['id']])); ?>"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
									</td>

								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End Row -->
</div>
</div>
</div>

<?php echo $__env->make('backend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\shiya\LARAVEL\eCommerce\resources\views/backend/profile.blade.php ENDPATH**/ ?>