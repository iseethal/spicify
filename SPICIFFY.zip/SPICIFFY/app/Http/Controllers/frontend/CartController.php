<?php

namespace App\Http\Controllers\frontend;

use App\Models\Cart;
use App\Models\Order;
use App\Models\Coupon;
use App\Models\WishList;
use App\Models\OrderItem;
use Illuminate\Http\Request;
use App\Models\CompareProduct;
use App\Models\VariantOptions;
use Illuminate\Support\Carbon;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;


class CartController extends Controller
{
    public function Cart()
    {
         $cart = Cart::where('user_id', Auth::id())->orderBy('id','desc')->get();

        return view('frontend.cart', compact('cart'));
    }


    public function AddToCart(Request $request)
    {
        $val           = $request->buynow;
        $productid     = $request->product_id;
        $quant         = $request->product_qty;
        $product       = VariantOptions::findOrFail($productid);
        $productname   = $product->name;
        $productimage  = $product->image;
        $productamount = $product->amount;
        $totalamount   = $productamount * $quant;

        // remove id from compare

        if(Session::has('compare')){

            if ($request->compare_id) {

                $id = $request->compare_id;

                Session::forget('compare.' . $id);

            }
        }

        // remove id from wishlist

        if(Session::has('wishlist')){

            if ($request->wishlist_id) {

                $id = $request->wishlist_id;

                Session::forget('wishlist.' . $id);

            }
        }


        if(Auth::id()){

            if(Session::has('cart')){

                $cart = session()->get('cart', []);
                foreach (session('cart') as $id =>  $cart_items ){

                    $variant_option_id = $cart_items['id'];
                    $product_name      = $cart_items['product_name'];
                    $image             = $cart_items['image'];
                    $quantity          = $cart_items['quantity'];
                    $amount            = $cart_items['amount'];
                    $total_amount      = $amount * $quantity;

                    $cart                    = new Cart;
                    $cart->user_id           = Auth::id();
                    $cart->variant_option_id = $variant_option_id;
                    $cart->product_name      = $product_name;
                    $cart->image             = $image;
                    $cart->quantity          = $quantity;
                    $cart->amount            = $amount;
                    $cart->total_amount      = $total_amount;
                    $cart->save();

                }

                $cart = session()->forget('cart');

                $cart                    = new Cart;
                $cart->user_id           = Auth::id();
                $cart->variant_option_id = $productid;
                $cart->product_name      = $productname;
                $cart->image             = $productimage;
                $cart->quantity          = $quant;
                $cart->amount            = $productamount;
                $cart->total_amount      = $totalamount;
                $cart->save();

             }


             $cart                    = new Cart;
             $cart->user_id           = Auth::id();
             $cart->variant_option_id = $productid;
             $cart->product_name      = $productname;
             $cart->image             = $productimage;
             $cart->quantity          = $quant;
             $cart->amount            = $productamount;
             $cart->total_amount      = $totalamount;
             $cart->save();

        }

       else {


            $cart = session()->get('cart', []);
            $i = 0;

            if (isset($cart[$productid])) {
                $cart[$productid]  = 1;

                $temp   = $productid;
                $value  = $request->session()->get('cart', 'id');

                if ($temp =  $value) {
                    return redirect()->route('frontend.shop');
                }
            } else {

                $cart[$productid] = [

                    "id"            => $productid,
                    "product_name"  => $productname,
                    "image"         => $productimage,
                    "quantity"      => $quant,
                    "amount"        => $productamount,
                    "total_amount"  => $totalamount,

                ];
            }

            session()->put('cart', $cart);
        }

        if ($val == 'buynow'){

            return redirect()->route('checkout');

        } else {

            return redirect()->back()->with('message','Product added to cart ');
        }


    }

    // session delete

    public function remove(Request $request)
    {
        if ($request->id) {

            $cart = session()->get('cart');

            if (isset($cart[$request->id])) {

                unset($cart[$request->id]);

                session()->put('cart', $cart);
            }

            session()->flash('error', 'Product removed ');
        }
    }

    public function RemoveCart($id)
    {
        Cart::destroy($id);
        return redirect()->back()->with('error','Product removed ');

    }

    public function WishList()
    {
        $wishlist = WishList::where('user_id', Auth::id())->orderBy('id','desc')->get();

        return view('frontend.wishlist', compact('wishlist'));
    }

    public function AddToWishList(Request $request)
    {
        $productid     = $request->product_id;
        $quant         = $request->product_qty;
        $product       = VariantOptions::findOrFail($productid);
        $productname   = $product->name;
        $productimage  = $product->image;
        $productamount = $product->amount;
        $totalamount   = $productamount * $quant;

        if(Auth::id()){

            if(Session::has('wishlist')){

                $wishlist = session()->get('wishlist', []);
                foreach (session('wishlist') as $id =>  $wishlist_items ){

                    $variant_option_id = $wishlist['id'];
                    $product_name      = $wishlist['product_name'];
                    $image             = $wishlist['image'];
                    $quantity          = $wishlist['quantity'];
                    $amount            = $wishlist['amount'];
                    $total_amount      = $amount * $quantity;

                    $wishlist                    = new WishList;
                    $wishlist->user_id           = Auth::id();
                    $wishlist->variant_option_id = $variant_option_id;
                    $wishlist->product_name      = $product_name;
                    $wishlist->image             = $image;
                    $wishlist->quantity          = $quantity;
                    $wishlist->amount            = $amount;
                    $wishlist->total_amount      = $total_amount;
                    $wishlist->save();

                }

                $wishlist = session()->forget('wishlist');

                $wishlist                    = new WishList;
                $wishlist->user_id           = Auth::id();
                $wishlist->variant_option_id = $productid;
                $wishlist->product_name      = $productname;
                $wishlist->image             = $productimage;
                $wishlist->quantity          = $quant;
                $wishlist->amount            = $productamount;
                $wishlist->save();

           }
             $wishlist                    = new WishList;
             $wishlist->user_id           = Auth::id();
             $wishlist->variant_option_id = $productid;
             $wishlist->product_name      = $productname;
             $wishlist->image             = $productimage;
             $wishlist->quantity          = $quant;
             $wishlist->amount            = $productamount;
             $wishlist->save();

        } else {


            $wishlist = session()->get('wishlist', []);
            $i = 0;

            if (isset($wishlist[$productid])) {
                $wishlist[$productid]  = 1;

                $temp   = $productid;
                $value  = $request->session()->get('wishlist', 'id');

                if ($temp =  $value) {
                    return redirect()->route('frontend.shop')->with('info','Product already added');
                }
            } else {

                $wishlist[$productid] = [

                    "id"            => $productid,
                    "product_name"  => $productname,
                    "image"         => $productimage,
                    "quantity"      => $quant,
                    "amount"        => $productamount,
                    "total_amount"  => $totalamount,

                ];
            }

            session()->put('wishlist', $wishlist);
        }

        return redirect()->back()->with('message','Product added to wishlist');

    }

    // public function RemoveWishList(Request $request)
    // {

    //     if ($request->id) {

    //         $wishlist = session()->get('wishlist');

    //         if (isset($wishlist[$request->id])) {

    //             unset($wishlist[$request->id]);

    //             session()->put('wishlist', $wishlist);
    //         }

    //         session()->flash('error', 'Product removed ');
    //     }

    // }

    public function DeleteWishList(Request $request)
    {

        $id = $request->id;

        if(Session::has('wishlist')){

                Session::forget('wishlist.' . $id);

                return redirect()->back()->with('error','Product removed successfully');

        } else {

            WishList::destroy($id);
            return redirect()->back()->with('error','Product removed ');

        }



    }

    public function Compare()
    {
        $compare = CompareProduct::where('user_id', Auth::id())->orderBy('id','desc')->get();

        return view('frontend.compare_products', compact('compare'));
    }

    public function AddToCompare(Request $request)
    {

        $productid     = $request->product_id;
        $quant         = $request->product_qty;
        $product       = VariantOptions::findOrFail($productid);
        $productname   = $product->name;
        $productimage  = $product->image;
        $productamount = $product->amount;
        $totalamount   = $productamount * $quant;
        $features      = $product->features;

        // dd($product->toArray());

        if(Auth::id()){

            if(Session::has('compare')){

                $compare = session()->get('compare', []);
                foreach (session('compare') as $id =>  $compare_items ){

                    $variant_option_id = $compare_items['id'];
                    $product_name      = $compare_items['product_name'];
                    $image             = $compare_items['image'];
                    $quantity          = $compare_items['quantity'];
                    $amount            = $compare_items['amount'];

                    $compare                    = new CompareProduct;
                    $compare->user_id           = Auth::id();
                    $compare->variant_option_id = $variant_option_id;
                    $compare->product_name      = $product_name;
                    $compare->image             = $image;
                    $compare->quantity          = $quantity;
                    $compare->amount            = $amount;
                    $compare->save();

                }

                $compare = session()->forget('compare');

                $compare                    = new CompareProduct;
                $compare->user_id           = Auth::id();
                $compare->variant_option_id = $productid;
                $compare->product_name      = $productname;
                $compare->image             = $productimage;
                $compare->quantity          = $quant;
                $compare->amount            = $productamount;
                $compare->save();

             }

             $compare                    = new CompareProduct;
             $compare->user_id           = Auth::id();
             $compare->variant_option_id = $productid;
             $compare->product_name      = $productname;
             $compare->image             = $productimage;
             $compare->quantity          = $quant;
             $compare->amount            = $productamount;
             $compare->save();


        } else {


            $compare = session()->get('compare', []);
            $i = 0;

            if (isset($compare[$productid])) {
                $compare[$productid]  = 1;

                $temp   = $productid;
                $value  = $request->session()->get('compare', 'id');

                if ($temp =  $value) {
                    return redirect()->route('frontend.shop')->with('info','Product already added ');
                }
            } else {

                $compare[$productid] = [

                    "id"            => $productid,
                    "product_name"  => $productname,
                    "image"         => $productimage,
                    "quantity"      => $quant,
                    "amount"        => $productamount,
                    "total_amount"  => $totalamount,
                    "features"      => $features,

                ];
            }

            session()->put('compare', $compare);
        }

        return redirect()->back()->with('message','Product added  to compare products');
    }


    public function RemoveFromCompare(Request $request)
    {
        $id = $request->id;

        if(Session::has('compare')){

            if ($request->compare_id) {

                $id = $request->compare_id;

                Session::forget('compare.' . $id);

                return redirect()->back()->with('error','Product removed successfully');

            }
        } else {

            CompareProduct::destroy($id);

            return redirect()->back()->with('error','Product removed successfully');

        }

    }

        //add to cart - compare products

    public function CompareToCart(Request $request)
    {

        $productid     = $request->product_id;
        $quant         = $request->product_qty;
        $product       = VariantOptions::findOrFail($productid);
        $productname   = $product->name;
        $productimage  = $product->image;
        $productamount = $product->amount;
        $totalamount   = $productamount * $quant;

        if(Session::has('cart')){

            $cart = session()->get('cart', []);
            foreach (session('cart') as $id =>  $cart_items ){

                $variant_option_id = $cart_items['id'];
                $product_name      = $cart_items['product_name'];
                $image             = $cart_items['image'];
                $quantity          = $cart_items['quantity'];
                $amount            = $cart_items['amount'];
                $total_amount      = $amount * $quantity;

                $cart                    = new Cart;
                $cart->user_id           = Auth::id();
                $cart->variant_option_id = $variant_option_id;
                $cart->product_name      = $product_name;
                $cart->image             = $image;
                $cart->quantity          = $quantity;
                $cart->amount            = $amount;
                $cart->total_amount      = $total_amount;
                $cart->save();

            }
        }

            $cart = session()->forget('cart');

            Cart::insert([

                'user_id'              => Auth::id(),
                'variant_option_id'    => $productid,
                'product_name'         => $productname,
                'image'                => $productimage,
                'quantity'             => $quant,
                'amount'               => $productamount,
                'total_amount'         => $totalamount,

            ]);

            if($request->id != null){

                CompareProduct::destroy($request->id);

            }

        return redirect()->back()->with('message','Product added to cart');
    }

    public function WishlistToCart(Request $request)
    {
        $productid     = $request->product_id;
        $quant         = $request->product_qty;
        $product       = VariantOptions::findOrFail($productid);
        $productname   = $product->name;
        $productimage  = $product->image;
        $productamount = $product->amount;
        $totalamount   = $productamount * $quant;


        if(Session::has('wishlist')){

            $wishlist = session()->get('wishlist', []);
            foreach (session('wishlist') as $id =>  $wishlist_items ){

                $variant_option_id = $wishlist['id'];
                $product_name      = $wishlist['product_name'];
                $image             = $wishlist['image'];
                $quantity          = $wishlist['quantity'];
                $amount            = $wishlist['amount'];
                $total_amount      = $amount * $quantity;

                $cart                    = new Cart;
                $cart->user_id           = Auth::id();
                $cart->variant_option_id = $variant_option_id;
                $cart->product_name      = $product_name;
                $cart->image             = $image;
                $cart->quantity          = $quantity;
                $cart->amount            = $amount;
                $cart->total_amount      = $total_amount;
                $cart->save();

            }
        }

            $cart = session()->forget('cart');

            Cart::insert([

                'user_id'              => Auth::id(),
                'variant_option_id'    => $productid,
                'product_name'         => $productname,
                'image'                => $productimage,
                'quantity'             => $quant,
                'amount'               => $productamount,
                'total_amount'         => $totalamount,

            ]);

            if($request->id != null){

                WishList::destroy($request->id);

            }

        return redirect()->back()->with('message','Product added to cart ');
    }

    // public function UpdateCart(Request $request){

    //     $cart               = Cart::find($request->id);
    //     $cart->quantity     = $request->quantity;
    //     $cart->total_amount = $request->total_amount;
    //     $cart->save();

    //     return redirect()->route('cart');

    // }

    public function UpdateCart(Request $request)
    {
        if (session('cart')) {

            if ($request->id && $request->quantity) {
                $cart = session()->get('cart');
                $cart[$request->id]["quantity"] = $request->quantity;
                session()->put('cart', $cart);
                session()->flash('message', 'Cart updated successfully');
            }
        } else {

            $cart               = Cart::find($request->id);
            $cart->quantity     = $request->quantity;
            $cart->total_amount = $request->total_amount;
            $cart->save();

            return redirect()->back()->with('message', 'Cart updated successfully');
        }

    }

}
