<?php echo $__env->make('backend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- Main Content-->
<div class="main-content side-content pt-0">
<div class="container-fluid">
<div class="inner-body">


    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h2 class="main-content-title tx-24 mg-b-5"> Orders</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('order.all')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"> All Orders</li>
            </ol>
        </div>

    </div>
    <!-- End Page Header -->

    <!-- Row -->
    <div class="row row-sm">
        <div class="col-lg-12">
            <div class="card custom-card overflow-hidden">
                <div class="card-body">

                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>  <?php echo e(session::get('success')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table id="exportexample" class="table table-bordered border-t0 key-buttons text-nowrap w-100" >
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Customer Name </th>
                                    <th>Customer Phone</th>
                                    <th>Transaction Id</th>
                                    <th>Total Amount</th>
                                    <th>Order Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            <?php $i= 1;   ?>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    if ($item->transaction_id =='COD') {

                                       $transaction = "Cash On Delivery";
                                    }  else {

                                       $transaction = "Razor Pay";
                                    }
                                ?>

                                <tr>
                                    <td> <?php echo e($i++); ?> </td>
                                    <td><?php echo e($item->billing_firstname); ?>  <?php echo e($item->billing_lastname); ?></td>
                                    <td><?php echo e($item->billing_phone); ?></td>
                                    <td><?php echo e($transaction); ?></td>
                                    <td><?php echo e($item->total); ?></td>
                                    <?php

                                        if ($item->order_status == 0)
                                        {
                                            $status_is    = "Order Placed";
                                        }
                                    elseif ($item->order_status == 1)
                                        {
                                            $status_is    = "In Progress";
                                        }
                                        else
                                        {
                                            $status_is    = "Delivered";
                                        }

                                    ?>

                                    <td><?php echo e($status_is); ?></td>

                                    <td>
                                        <a href="<?php echo e(route('order.view',['id'=>$item['id']])); ?>"><i class="fa fa-eye" style="color: green;"></i></a> &nbsp;&nbsp;&nbsp;&nbsp;
                                        
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Row -->


</div>
</div>
</div>
<!-- End Main Content-->



<?php echo $__env->make('backend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\shiya\LARAVEL\eCommerce\resources\views/backend/orders/orders.blade.php ENDPATH**/ ?>