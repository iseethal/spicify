<?php
use App\Models\Cart;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

?>


<style>
    .cartmini__checkout-btn .tp-btn:hover {
        background-color: #006677;
        color: var(--tp-common-white);
        border-color: #006475;
    }

    .cartmini__title a:hover {
        color: #006475;
    }

    .cartmini__price {
        color: #010f1c;
    }
</style>
<!-- cart mini area start -->
<?php
    $grandtotal = 0;

    if (session::has('cart')) {
        $cartcount = count(Session::get('cart', []));
    } else {
        $cartcount = Cart::where('user_id', Auth::id())->count();
    }
?>
<?php if(session('cart')): ?>

    <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $cart_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $grandtotal += $cart_items['amount'] * $cart_items['quantity'];
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <div class="cartmini__area">
        <div class="cartmini__wrapper d-flex justify-content-between flex-column">
            <div class="cartmini__top-wrapper">
                <div class="cartmini__top p-relative">
                    <div class="cartmini__top-title">
                        <h4>Shopping cart</h4>
                    </div>
                    <div class="cartmini__close">
                        <button type="button" class="cartmini__close-btn cartmini-close-btn"><i
                                class="fal fa-times"></i></button>
                    </div>
                </div>


                <div class="cartmini__widget">
                    <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $cart_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="cartmini__widget-item">
                            <div class="cartmini__thumb">
                                <a href="<?php echo e(route('frontend.single_product', ['id' => $id])); ?>">
                                    <img src="<?php echo e(url('backend/images/product_images/' . $cart_items['image'])); ?>"
                                        alt="">
                                </a>
                            </div>
                            <div class="cartmini__content">
                                <h5 class="cartmini__title"><a
                                        href="<?php echo e(route('frontend.single_product', ['id' => $id])); ?>"><?php echo e(Str::limit($cart_items['product_name'], 20)); ?></a>
                                </h5>
                                <div class="cartmini__price-wrapper">
                                    <span class="cartmini__price"
                                        style="color: 006475">₹<?php echo e($cart_items['amount']); ?></span>
                                    <span class="cartmini__quantity">x<?php echo e($cart_items['quantity']); ?></span>
                                </div>
                            </div>
                            
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>

                

            </div>

            <?php if($cartcount != null): ?>
                <div class="cartmini__checkout">
                    <div class="cartmini__checkout-title mb-30">
                        <h4>Subtotal:</h4>
                        <span> ₹<?php echo e($grandtotal); ?></span>
                    </div>
                    <div class="cartmini__checkout-btn">
                        <a href="<?php echo e(route('cart')); ?>" class="tp-btn mb-10 w-100"> view cart</a>
                        <a href=" <?php echo e(route('checkout')); ?>" class="tp-btn tp-btn-border w-100"> checkout</a>
                    </div>
                </div>
            <?php endif; ?>



        </div>
    </div>
<?php else: ?>
    <?php
        $cart = App\Models\Cart::where('user_id', Auth::id())
            ->orderBy('id', 'desc')
            ->get();
    ?>

    <div class="cartmini__area">
        <div class="cartmini__wrapper d-flex justify-content-between flex-column">
            <div class="cartmini__top-wrapper">
                <div class="cartmini__top p-relative">
                    <div class="cartmini__top-title">
                        <h4>Shopping cart</h4>
                    </div>
                    <div class="cartmini__close">
                        <button type="button" class="cartmini__close-btn cartmini-close-btn"><i
                                class="fal fa-times"></i></button>
                    </div>
                </div>

                <div class="cartmini__widget">
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="cartmini__widget-item">
                            <div class="cartmini__thumb">
                                <a
                                    href="<?php echo e(route('frontend.single_product', ['id' => $cart_items['variant_option_id']])); ?>">
                                    <img src="<?php echo e(url('backend/images/product_images/' . $cart_items['image'])); ?>"
                                        alt="">
                                </a>
                            </div>
                            <div class="cartmini__content">
                                <h5 class="cartmini__title"><a
                                        href="<?php echo e(route('frontend.single_product', ['id' => $cart_items['variant_option_id']])); ?>"><?php echo e(Str::limit($cart_items['product_name'], 15)); ?></a>
                                </h5>
                                <div class="cartmini__price-wrapper">
                                    <span class="cartmini__price">₹<?php echo e($cart_items['amount']); ?></span>
                                    <span class="cartmini__quantity">x<?php echo e($cart_items['quantity']); ?></span>
                                </div>
                            </div>

                            <a href="<?php echo e(route('cart.delete', $cart_items->id)); ?>" class="cartmini__del"><i
                                    class="fa-regular fa-xmark"></i></a>

                        </div>

                        <?php  $grandtotal += $cart_items['amount'] * $cart_items['quantity']; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>

                <div class="cartmini__empty text-center d-none">
                    <img src="assets/img/product/cartmini/empty-cart.png" alt="">
                    <p>Your Cart is empty</p>
                    <a href="shop.html" class="tp-btn">Go to Shop</a>
                </div>
            </div>
            <div class="cartmini__checkout">
                <div class="cartmini__checkout-title mb-30">
                    <h4>Subtotal:</h4>
                    <span> ₹<?php echo e($grandtotal); ?></span>
                </div>
                <div class="cartmini__checkout-btn">
                    <a href="<?php echo e(route('cart')); ?>" class="tp-btn mb-10 w-100"> view cart</a>
                    <a href="<?php echo e(route('checkout')); ?>" class="tp-btn tp-btn-border w-100"> checkout</a>
                </div>
            </div>
        </div>
    </div>

<?php endif; ?>
<!-- cart mini area end -->
<?php /**PATH C:\xampp\htdocs\shiya\LARAVEL\kriztle_new\kriztle_project\resources\views/frontend/templates/mini_cart.blade.php ENDPATH**/ ?>