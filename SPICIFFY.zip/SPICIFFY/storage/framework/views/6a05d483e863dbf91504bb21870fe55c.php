<?php echo $__env->make('backend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="main-content side-content pt-0">
				<div class="container-fluid">
					<div class="inner-body">

			<!-- Page Header -->
			<div class="page-header">
				<div>
					<h2 class="main-content-title tx-24 mg-b-5">Welcome To Dashboard</h2>
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
						<li class="breadcrumb-item active" aria-current="page"> Dashboard</li>
					</ol>
				</div>
				<!-- <div class="d-flex">
					<div class="justify-content-center">
						<button type="button" class="btn btn-white btn-icon-text my-2 mr-2">
							<i class="fe fe-download mr-2"></i> Import
						</button>
						<button type="button" class="btn btn-white btn-icon-text my-2 mr-2">
							<i class="fe fe-filter mr-2"></i> Filter
						</button>
						<button type="button" class="btn btn-primary my-2 btn-icon-text">
							<i class="fe fe-download-cloud mr-2"></i> Download Report
						</button>
					</div>
				</div> -->
			</div>
			<!-- End Page Header -->


			<!--Row-->
		<div class="row row-sm">
			<div class="col-sm-12 col-lg-12 col-xl-12">

				<!--Row-->
				<div class="row row-sm  mt-lg-4">
					<div class="col-sm-12 col-lg-12 col-xl-12">
						<div class="card bg-primary custom-card card-box">
							<div class="card-body p-4">
								<div class="row align-items-center">
									<div class="offset-xl-3 offset-sm-6 col-xl-8 col-sm-6 col-12 img-bg ">
										<h4 class="d-flex  mb-3">
											<span class="font-weight-bold text-white "></span>
										</h4>
                                        <a href="">
										<p class="tx-white-7 mb-1"> Welcome</p></a>
									</div>
									<img src="assets/img/pngs/work3.png" alt="user-img" class="wd-200">
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--Row -->

				<!--Row-->
			

		</div>

				</div><!-- col end -->

				<!-- col end -->
			</div><!-- Row end -->

<!-- Row-->


<!-- Row End -->


					</div>
				</div>
			</div>



 <?php echo $__env->make('backend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\shiya\LARAVEL\KRIZTLE\kriztle_project\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>