<?php

namespace App\Http\Controllers\frontend;

use App\Models\Contact;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Http\Controllers\Controller;

class ContactController extends Controller
{
    public function Contact()
    {
        return view('frontend.contact');
    }

    public function SaveContact(Request $request)
    {
        Contact::insert([

            'name'        => $request->name,
            'phone'       => $request->phone,
            'email'       => $request->email,
            'subject'     => $request->subject?? "",
            'message'     => $request->message?? "",
            'created_at'  => Carbon::now('Asia/Kolkata'),

        ]);

        return redirect()->back()->with('message','Form submitted successfully');
    }

    public function AllContact()
    {
        $contacts = Contact::where('is_deleted','<>',1)->get();
        return view('backend.contact.all_contact', compact('contacts'));
    }

    public function ViewContact(Request $request)
    {
        $id      = $request->id;
        $contact = Contact::findOrFail($id);
        return view('backend.contact.view_contact', compact('contact'));
    }

      public function DeleteContact($id)
    {
        Contact::findOrFail($id)->update([

            'is_deleted'     => 1,
        ]);

        return redirect()->back()->with('error', 'contact Removed' );
    }

    public function AboutUs()
    {
         return view('frontend.about_us');
    }
}
