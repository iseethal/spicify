<?php echo $__env->make('frontend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.templates.toastr-notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<style>
    .tp-checkout-btn {
        background-color: #006677;
    }
</style>

<main>

    <!-- breadcrumb area start -->
    <section class="breadcrumb__area include-bg text-center pt-95 pb-50">
        <div class="container">
           <div class="row">
              <div class="col-xxl-12">
                 <div class="breadcrumb__content p-relative z-index-1">
                    <h3 class="breadcrumb__title">Payment</h3>
                    <div class="breadcrumb__list">
                       <span><a href="<?php echo e(route('frontend.home')); ?>">Home</a></span>
                       <span>Payment</span>
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </section>
    <!-- breadcrumb area end -->



    <!-- checkout area start -->
    <section class="tp-contact-area pb-100">
        <div class="container">
           <div class="tp-contact-inner">
              <div class="row">

                <div class="col-md-6 ">
                    <div class="tp-checkout-bill-area">
                        <h3 class="tp-checkout-bill-title">Billing Details</h3>

                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php
                                $name  =  $item->billing_firstname.''.$item->billing_lastname;
                                $phone =  $item->billing_phone;
                                $email =  $item->billing_email;
                            ?>

                        <div class="tp-checkout-bill-form">
                            <p style="font-size: 18px;"> <?php echo e($item->billing_firstname); ?> <?php echo e($item->billing_lastname); ?> </p>
                            <p style="font-size: 18px;"> <?php echo e($item->billing_email); ?> </p>
                            <p style="font-size: 18px;"> <?php echo e($item->billing_phone); ?> </p>
                            <p style="font-size: 18px;"> <?php echo e($item->billing_address1); ?> </p>
                            <p style="font-size: 18px;"> <?php echo e($item->billing_address2); ?> </p>
                            <p style="font-size: 18px;"> <?php echo e($item->billing_city); ?> , <?php echo e($item->country); ?>,<?php echo e($item->billing_state); ?></p>
                            <p style="font-size: 18px;"> <?php echo e($item->billing_zip_code); ?> </p>

                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <!-- checkout place order -->
                    <div class="tp-checkout-place white-bg">
                        <h3 class="tp-checkout-place-title">Your Order</h3>

                        <div class="tp-order-info-list">
                            <ul>

                                <!-- header -->
                                <li class="tp-order-info-list-header">
                                    <h4>Product</h4>
                                    <h4>Total</h4>
                                </li>

                                <!-- item list -->
                                <?php $grandtotal = 0; ?>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php
                                $order_id    = $item->id;
                                $order_items = App\Models\OrderItem::where('order_id', $order_id)->get();
                                ?>

                                    <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="tp-order-info-list-desc">
                                                <p><?php echo e($item1->product_name); ?>. <span> x <?php echo e($item1->quantity); ?></span></p>
                                                <span>₹<?php echo e($item1->amount); ?></span>
                                            </li>

                                            <?php
                                                $grandtotal += $item->total_amount;
                                            ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                <!-- subtotal -->
                                <li class="tp-order-info-list-subtotal">
                                    <span>Subtotal</span>
                                    <span>₹<?php echo e($item->total); ?> </span>
                                </li>

                                <!-- shipping -->
                                

                                <!-- total -->
                                <li class="tp-order-info-list-total">
                                    <span>Total</span>
                                    <span>₹<?php echo e($item->total); ?></span>
                                </li>
                            </ul>
                        </div>
                        <br><br>
                        <div class="tp-checkout-btn-wrapper">
                            <button type="submit" class="tp-checkout-btn w-100"  value="paynow" id="rzp-button1">Pay Now</button>
                        </div>
                    </div>
                </div>

              </div>
           </div>
        </div>
     </section>
    <!-- checkout area end -->


</main>


<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
    var urls= "<?php echo e(route('success')); ?>"
var options = {
    "key": "rzp_test_APvrNv6aeKU8tq", // Enter the Key ID generated from the Dashboard
    "amount": "<?php echo e($razorpayOrder->amount); ?>", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
    "currency": "INR",
    "name": "GIS Axiom",
    "description": "Supermarket",
    "image": "https://www.gisaxiom.com/assets/images/logo-dark.png",
    "order_id": "<?php echo e($razorpayOrder->id); ?>", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1

    "handler": function (response){

        console.log();

        window.location.href = urls+'?payment_id='+response.razorpay_payment_id;
    },

    "callback_url": "https://eneqd3r9zrjok.x.pipedream.net/",
    "prefill": {
        "name": "<?php echo e($name); ?>",
        "email": "<?php echo e($email); ?>",
        "contact" : "<?php echo e($phone); ?>"
    },
    "notes": {
        "address": "Razorpay Corporate Office"
    },
    "theme": {
        "color": "#3399cc"
    }
};
var rzp1 = new Razorpay(options);
document.getElementById('rzp-button1').onclick = function(e){
    rzp1.open();
    e.preventDefault();
}
</script>

<?php echo $__env->make('frontend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\shiya\LARAVEL\eCommerce\resources\views/frontend/payment.blade.php ENDPATH**/ ?>