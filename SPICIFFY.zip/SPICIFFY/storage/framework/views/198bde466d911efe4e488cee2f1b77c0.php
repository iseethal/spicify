<?php echo $__env->make('backend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="main-content side-content pt-0">
    <div class="container-fluid">
        <div class="inner-body">

            <!-- Page Header -->
            <div class="page-header">
                <div>
                    <h2 class="main-content-title tx-24 mg-b-5">Contact View</h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('contact.all')); ?>">Contact</a></li>
                        <li class="breadcrumb-item active" aria-current="page">View</li>
                    </ol>
                </div>

            </div>

            <div class="row row-sm">
                <div class="col-lg-12 col-md-12">
                    <div class="card custom-card">
                        <div class="card-body">
                            <div class="main-content-title tx-24 mg-b-5">
                                <h6 class="main-content-label mb-1"> Order View </h6>
                            </div>
                            <br>
                            <hr>


                            <div class="row row-xs align-items-center mg-b-20">
                                <div class="col-md-4">
                                    <label class="mg-b-0" style="font-weight:500;">Name <span
                                            style="padding-left:88px;">:</span></label>
                                </div>

                                <div class="col-md-8 mg-t-5 mg-md-t-0">
                                    <?php echo e($contact->name); ?>

                                </div>

                            </div>


                            <div class="row row-xs align-items-center mg-b-20">
                                <div class="col-md-4">
                                    <label class="mg-b-0" style="font-weight:500;">Email <span
                                            style="padding-left:89px;">:</span></label>
                                </div>
                                <div class="col-md-8 mg-t-5 mg-md-t-0">

                                    <?php echo e($contact->email); ?>

                                </div>
                            </div>

                            <div class="row row-xs align-items-center mg-b-20">
                                <div class="col-md-4">
                                    <label class="mg-b-0" style="font-weight:500;">Phone <span
                                            style="padding-left:83px;">:</span></label>
                                </div>
                                <div class="col-md-8 mg-t-5 mg-md-t-0">

                                    <?php echo e($contact->phone); ?>

                                </div>
                            </div>

                            <?php if( $contact->subject != null): ?>
                                <div class="row row-xs align-items-center mg-b-20">
                                    <div class="col-md-4">
                                        <label class="mg-b-0" style="font-weight:500;">Subject <span
                                                style="padding-left:77px;">:</span></label>
                                    </div>
                                    <div class="col-md-8 mg-t-5 mg-md-t-0">

                                        <?php echo e($contact->subject); ?>

                                    </div>
                                </div>

                            <?php endif; ?>

                           <?php if($contact->message != null): ?>
                            <div class="row row-xs align-items-center mg-b-20">
                                <div class="col-md-4">
                                    <label class="mg-b-0" style="font-weight:500;">Message <span
                                            style="padding-left:66px;">:</span></label>
                                </div>
                                <div class="col-md-8 mg-t-5 mg-md-t-0">

                                    <?php echo e($contact->message); ?>

                                </div>
                            </div>
                           <?php endif; ?>



                        </div>
                    </div>
                </div>
            </div>
            <!-- End Row -->

        </div>
    </div>
</div>


<?php echo $__env->make('backend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\GisAxiom\KRISTLE\kriztle_project\resources\views/backend/contact/view_contact.blade.php ENDPATH**/ ?>