<?php

namespace App\Http\Controllers\frontend;

use App\Models\Cart;
use App\Models\Order;
use App\Models\Coupon;
use App\Models\OrderItem;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class CheckoutController extends Controller
{
    public function Checkout()
    {
        $cart      = Cart::where('user_id', Auth::id())->get();
        $cartcount = Cart::where('user_id', Auth::id())->count();

        if(Auth::id()){

            return view('frontend.checkout', compact('cart'));

        } else {
            return redirect()->route('login');

        }

    }

    public function StoreCheckout(Request $request)
    {
        $cart      = Cart::where('user_id', Auth::id())->get();
        $cartcount = Cart::where('user_id', Auth::id())->count();
        $val1      = $request->payment_type;

        $total     = 0;
        foreach ($cart as $item) {
            $total += $item['amount'] * $item['quantity'];
        }

        if($cartcount > 0){

            // shiya - 05/09/23
            $billing_zip_code  = $request->input("billing_zip_code");


            // ends

            if ($val1 == 'cash_on_delivery'){

                $orders                    = new Order();
                $orders->user_id           = Auth::id();
                $orders->transaction_id    = 'COD';
                $orders->order_date        = Carbon::now('Asia/Kolkata');
                $orders->billing_firstname = $request->input("billing_firstname");
                $orders->billing_lastname  = $request->input("billing_lastname");
                $orders->billing_phone     = $request->input("billing_phone");
                $orders->billing_email     = $request->input("billing_email");
                $orders->billing_address1  = $request->input("billing_address1");
                $orders->billing_address2  = $request->input("billing_address2");
                $orders->billing_city      = $request->input("billing_city");
                $orders->billing_state     = $request->input("billing_state");
                $orders->billing_zip_code  = $request->input("billing_zip_code");
                $orders->order_notes       = $request->input("order_notes");
                $orders->country           = $request->input("country");
                $orders->total             = $total;
                $orders->save();

                $orders->id;

                foreach ($cart as $item) {

                    OrderItem::create([
                        'order_id'      =>$orders->id,
                        'product_id'   =>$item->product_id,
                        'product_name' =>$item->product_name,
                        'quantity'     =>$item->quantity,
                        'amount'       =>$item->amount,
                        'total'        =>$total,
                        'image'        =>$item->image,

                    ]);
                }

                Cart::destroy($cart);

                return redirect()->route('my-account');

            }  else  {

            $orders                    = new Order();
            $orders->user_id           = Auth::id();
            $orders->transaction_id    = '1234';
            $orders->order_date        = Carbon::now('Asia/Kolkata');
            $orders->billing_firstname = $request->input("billing_firstname");
            $orders->billing_lastname  = $request->input("billing_lastname");
            $orders->billing_phone     = $request->input("billing_phone");
            $orders->billing_email     = $request->input("billing_email");
            $orders->billing_address1  = $request->input("billing_address1");
            $orders->billing_address2  = $request->input("billing_address2");
            $orders->billing_city      = $request->input("billing_city");
            $orders->billing_state     = $request->input("billing_state");
            $orders->billing_zip_code  = $request->input("billing_zip_code");
            $orders->order_notes       = $request->input("order_notes");
            $orders->country           = $request->input("country");
            $orders->total             = $total;
            $orders->save();

            $orders->id;

            foreach ($cart as $item) {

                OrderItem::create([
                    'order_id'      =>$orders->id,
                    'product_id'   =>$item->product_id,
                    'product_name' =>$item->product_name,
                    'quantity'     =>$item->quantity,
                    'amount'       =>$item->amount,
                    'total'        =>$total,
                    'image'        =>$item->image,

                ]);
            }

            Cart::destroy($cart);

            return redirect()->route('payment');
        }
    }


    }
}
